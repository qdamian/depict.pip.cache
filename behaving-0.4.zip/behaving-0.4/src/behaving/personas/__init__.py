# Generic setup/teardown for compatibility with pytest et al.


def setup(context):
    context.personas = {}
